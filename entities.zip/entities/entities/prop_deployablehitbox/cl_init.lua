INC_CLIENT()

function ENT:Initialize()
	self:DrawShadow(false)
	self:SetNoDraw(true)
end

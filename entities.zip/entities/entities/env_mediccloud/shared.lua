ENT.Type = "anim"

ENT.Radius = 100

ENT.Type = "point"

function ENT:Initialize()
	GAMEMODE.NoSkills = true
end

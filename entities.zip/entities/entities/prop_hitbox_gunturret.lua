AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "prop_deployablehitbox"

ENT.BoxMin = Vector(-20, -16, 0)
ENT.BoxMax = Vector(24, 16, 64)

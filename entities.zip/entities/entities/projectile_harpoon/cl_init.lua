INC_CLIENT()

function ENT:Draw()
	self:DrawModel()
end

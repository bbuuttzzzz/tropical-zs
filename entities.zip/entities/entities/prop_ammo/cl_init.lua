INC_CLIENT()

ENT.ColorModulation = Color(0.25, 1, 0.25)

AddCSLuaFile()

ENT.Type = "point"

function ENT:UpdateTransmitState()
	return TRANSMIT_PVS
end
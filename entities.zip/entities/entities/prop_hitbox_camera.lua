AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "prop_deployablehitbox"

ENT.BoxMin = Vector(-8, -8, 0)
ENT.BoxMax = Vector(8, 8, 8)

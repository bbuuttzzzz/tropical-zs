ENT.Base = "projectile_corgasgrenade"

ENT.Base = "projectile_ghoulfleshchilled"

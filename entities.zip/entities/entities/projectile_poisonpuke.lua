AddCSLuaFile()

ENT.Base = "projectile_poisonflesh"
ENT.Type = "anim"

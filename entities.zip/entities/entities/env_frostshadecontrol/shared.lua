ENT.Type = "anim"

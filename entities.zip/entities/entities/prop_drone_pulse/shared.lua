ENT.Base = "prop_drone"

ENT.DeployableAmmo = "pulse_cutter"
ENT.SWEP = "weapon_zs_drone_pulse"
ENT.AmmoType = "pulse"

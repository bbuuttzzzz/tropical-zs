ENT.Type = "anim"

ENT.Radius = 75

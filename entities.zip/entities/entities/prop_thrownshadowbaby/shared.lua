ENT.Base = "prop_thrownbaby"

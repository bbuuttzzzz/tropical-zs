ENT.Base = "prop_zapper"

ENT.Damage = 55

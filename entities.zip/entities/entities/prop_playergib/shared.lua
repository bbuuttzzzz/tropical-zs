ENT.Type = "anim"

ENT.NoNails = true

function ENT:HumanHoldable(pl)
	return false
end

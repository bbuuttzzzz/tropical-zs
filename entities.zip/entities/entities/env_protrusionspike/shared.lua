ENT.Type = "anim"

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.IgnoreBullets = true
ENT.IgnoreMelee = true
ENT.IgnoreTraces = true

util.PrecacheModel("models/props_wasteland/rockcliff06d.mdl")
util.PrecacheSound("physics/glass/glass_largesheet_break1.wav")
util.PrecacheSound("physics/glass/glass_largesheet_break2.wav")
util.PrecacheSound("physics/glass/glass_largesheet_break3.wav")

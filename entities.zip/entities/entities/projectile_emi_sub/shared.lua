ENT.Base = "projectile_emi"

ENT.Type = "anim"
